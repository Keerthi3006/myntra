# Twitter Clone
### Twitter clone built with Pure CSS + HTML + JS
## 🎴 Layout
![image](https://user-images.githubusercontent.com/48324076/95918482-cae88b00-0da3-11eb-936a-1dec670eb250.png)

###### 🚀🔥 [See in action](https://baziotabeans.github.io/twitter_clone/)

## 💻 Technologies
- [HTML5](https://www.w3schools.com/html/)
- [CSS3](https://www.w3schools.com/css/)
- [Javascript](https://www.w3schools.com/js/DEFAULT.asp)

## 📕 License Released in 2020 [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Made with ❤ by [Fábio Baziota] 🚀.
Give a ⭐️ if this project helped you!


